<?php
http_response_code(403);
?>
<h1>403</h1>
<p>Accesso non autorizzato</p>
